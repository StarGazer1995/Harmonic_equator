// -----------------------------------------------------------------------------------
// Version information for SWS
#include "Version.h"

Version firmwareVersion;
