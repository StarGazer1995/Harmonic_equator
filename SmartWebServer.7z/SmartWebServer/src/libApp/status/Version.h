// -----------------------------------------------------------------------------------
// Version information for SWS
#pragma once

class Version {
  public:
    char str[30];
};

extern Version firmwareVersion;
