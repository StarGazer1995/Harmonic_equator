// -----------------------------------------------------------------------------------
// Settings
#pragma once

#include "../htmlHeaders.h"
#include "../htmlMessages.h"
#include "../htmlScripts.h"

#include "SelectTile.h"
#include "HomeTile.h"
#include "SlewingTile.h"
#include "BacklashTcfTile.h"
