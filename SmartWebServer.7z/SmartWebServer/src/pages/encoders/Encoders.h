// -----------------------------------------------------------------------------------
// Encoders
#pragma once

#include "../htmlHeaders.h"
#include "../htmlMessages.h"
#include "../htmlScripts.h"

#if ENCODERS == ON
  #include "SyncTile.h"
  #include "AxisTile.h"
#endif
